require('dotenv').config();
const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// In-memory "database" (resets when the server restarts)
const users = [];
let nextId = 1;

// ---------- Middleware ----------

// Bonus: custom request logger
function requestLogger(req, res, next) {
  const start = Date.now();
  res.on('finish', () => {
    const ms = Date.now() - start;
    console.log(
      `[${new Date().toISOString()}] ${req.method} ${req.originalUrl} -> ${res.statusCode} (${ms}ms)`
    );
  });
  next();
}

app.use(requestLogger);
app.use(express.json());                                   // JSON parsing
app.use(express.static(path.join(__dirname, 'public')));   // serves public/index.html at /

// ---------- Routes ----------

// GET /api -> welcome message
app.get('/api', (req, res) => {
  res.json({ message: 'Welcome to My Week 2 API' });
});

// POST /user -> accepts { name, email }, replies "Hello <name>"
app.post('/user', (req, res) => {
  const { name, email } = req.body || {};

  if (!name || !email) {
    return res.status(400).json({ error: 'Both "name" and "email" are required.' });
  }

  const user = { id: nextId++, name, email };
  users.push(user);

  res.status(201).json({ message: `Hello ${name}`, user });
});

// GET /user/:id -> user profile
app.get('/user/:id', (req, res) => {
  const id = Number(req.params.id);

  if (!Number.isInteger(id)) {
    return res.status(400).json({ error: 'User ID must be a number.' });
  }

  const user = users.find((u) => u.id === id);
  if (!user) {
    return res.status(404).json({ error: `User ${id} not found.` });
  }

  res.json(user);
});

// ---------- Error handling ----------

// Unknown route
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found.' });
});

// Malformed JSON and any other error
app.use((err, req, res, next) => {
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'Invalid JSON in request body.' });
  }
  console.error(err);
  res.status(500).json({ error: 'Something went wrong on the server.' });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
