# My Week 2 API

Express.js API with JSON parsing, error handling, .env config, a static page, and a request-logging middleware.

## Run
```
npm install
cp .env.example .env   # set PORT
npm start
```

## Endpoints
| Method | Route | Description |
|---|---|---|
| GET | `/` | Static HTML page |
| GET | `/api` | Welcome message |
| POST | `/user` | Body `{ "name", "email" }` -> `Hello <name>` (400 if missing) |
| GET | `/user/:id` | User profile (404 if not found) |

## Test
```
curl http://localhost:3000/api
curl -X POST http://localhost:3000/user -H "Content-Type: application/json" -d '{"name":"Ama","email":"ama@example.com"}'
curl http://localhost:3000/user/1
curl -X POST http://localhost:3000/user -H "Content-Type: application/json" -d '{"name":"Ama"}'
```
